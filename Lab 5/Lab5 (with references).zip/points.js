// some globals
var gl;
var delay = 1000;
var MaxPoints = 100;
var gl, program, vertLoc, counter = 0;

var vertices = [];
var rotate = false;
var scale = false;


window.onload = function init() {
	// get the canvas handle from the document's DOM
	var canvas = document.getElementById("gl-canvas");
	// initialize webGL
	gl = initWebGL(canvas);
	// check for errors
	if(!gl)
		alert( "WebGL␣isn’t␣available" );
	
	// set up a viewing surface to display your image: origin , size
	gl.viewport( 0, 0, canvas.width , canvas.height );

	// clear display with a background color (RGB triplet in 0 -1.0 range)
	gl.clearColor( 0.5, 0.5, 0.5, 1.0 );

	// Load shaders -- all work done in init_shaders .js
	program = initShaders(gl, "vertex-shader", "fragment-shader");

	// make this the current shader program
	gl.useProgram(program);

	// Get a location (address) of the shader variable ’vertPos ’
	// vertLoc = gl.getUniformLocation(program , "xform_matrix");
	// create a vertex buffer - to hold point data
	vBuffer = gl.createBuffer();

	
	// set this buffer the active buffer for subsequent operations on it
	gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer);

	// Associate our shader variables with our data buffer
    // note: "vposition" is a named variable used in the vertex shader and is
    // associated with vPosition here
    var vPosition = gl.getAttribLocation( program, "vPosition");
	matrix = gl.getUniformLocation(program, "xform_matrix");

    // specify the format of the vertex data - here it is a float with
    // 2 coordinates per vertex - these are its attributes
    gl.vertexAttribPointer(vPosition, 2, gl.FLOAT, false, 0, 0);

    // enable the vertex attribute array 
    gl.enableVertexAttribArray(vPosition);

	generateSquare();

    render();
};

function generateSquare(){
 
    vertices.push(-.5, .5, -.5, -.5, .5, -.5, -.5, .5, .5, .5, .5, -.5);
    
    // text_area.value += "Make square. \n";
    var translationMatrix = [
        1, 0, 0, 0,
        0, 1, 0, 0,
        0, 0, 1, 0,
        0, 0, 0, 1 ];

    // uniformMatrix4fv(location, transpose, array)
    // transpose must be false in WebGL.
    gl.uniformMatrix4fv(matrix, false, flatten(translationMatrix));
    gl.bufferData (gl.ARRAY_BUFFER, flatten(vertices), gl.STATIC_DRAW);
    gl.drawArrays(gl.TRIANGLES, 0, 2);
    gl.useProgram(program);
}

function render() {
    gl.clear( gl.COLOR_BUFFER_BIT );

	if (counter < MaxPoints) {
		var x = -.9 + Math.random()*2;
		var y = -.9 + Math.random()*2;
		var val = .025;
        vertices.push(-.5, .5, -.5, -.5, .5, -.5, -.5, .5, .5, .5, .5, -.5);
		counter++;	
		gl.bufferData (gl.ARRAY_BUFFER, flatten(vertices), gl.STATIC_DRAW);
	}

    gl.drawArrays(gl.TRIANGLES, 0, counter);
	gl.useProgram(program);

    setTimeout(
        function (){requestAnimFrame(render);}, delay
    );
}



